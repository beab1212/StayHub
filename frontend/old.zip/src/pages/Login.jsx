import { AuthForm } from '../components/AuthForm';

export const Login = () => {
  return <AuthForm mode="login" />;
};
